# PenHub — Codex 2 Plan: Typed Actions, Observation Compression, Evidence, Replay & Report

> Vai trò: **Actions, Evidence & Report Lead**  
> Branch chuẩn: `codex/2-actions-evidence-report`  
> Mục tiêu: xây action runtime cho CTF/pentest, nén observations, ghi evidence, tạo replay steps và sinh report cuối.

---

## 1. Mục tiêu của Codex 2

Codex 2 xây phần cho phép PenHub làm việc như pentester có kỷ luật:

```text
1. Mọi tool/action có typed input/output.
2. Raw output không đi thẳng vào model context.
3. Observation được nén thành facts/evidence/errors.
4. Evidence được lưu với artifact path/hash.
5. Report được sinh từ state/evidence, không từ chat transcript.
```

Codex 2 sở hữu:

```text
- Typed Action Runtime
- Observation Compressor
- Evidence Recorder
- Replay Builder
- Report Generator
- Action-level parsers
```

---

## 2. Git branch và worktree

Tạo workspace riêng:

```bash
git fetch origin
git worktree add ../penhub-worktrees/codex-2-actions -b codex/2-actions-evidence-report origin/dev
cd ../penhub-worktrees/codex-2-actions
```

Trước khi code:

```bash
git branch --show-current
git status --short
git fetch origin
git rebase origin/dev
```

Trước khi push:

```bash
git fetch origin
git rebase origin/dev
make check
git diff --check
git push -u origin codex/2-actions-evidence-report
```

Nếu đã push rồi và cần push sau rebase:

```bash
git push --force-with-lease origin codex/2-actions-evidence-report
```

---

## 3. Ownership: Codex 2 được sửa gì?

Codex 2 được sửa:

```text
packages/actions/**
packages/tools/**
packages/observation/**
packages/evidence/**
packages/replay/**
packages/report/**
packages/parsers/**
packages/types/actions/**
tests/actions/**
tests/observation/**
tests/evidence/**
tests/replay/**
tests/report/**
fixtures/actions/**
fixtures/evidence/**
fixtures/report/**
```

Codex 2 không được sửa nếu chưa có approval:

```text
packages/core/**
packages/state/**
packages/context/**
packages/hypotheses/**
packages/attack-tree/**
packages/token-budget/**
apps/penhub-ui/**
benchmarks/**
harness/**
.github/**
package.json
pnpm-lock.yaml
yarn.lock
package-lock.json
Makefile
README.md
```

Nếu cần dùng type của Codex 1, import từ:

```text
packages/types/core
```

Không duplicate type.

---

## 4. Module structure

```text
packages/
  actions/
    src/
      action-registry.ts
      action-runner.ts
      action-types.ts
      actions/
        inspect-tree.ts
        summarize-files.ts
        extract-routes.ts
        extract-inputs.ts
        extract-sinks.ts
        run-local-app.ts
        send-request.ts
        compare-responses.ts
        inspect-logs.ts
        record-evidence.ts
        update-hypothesis.ts
        generate-report.ts
      index.ts

  observation/
    src/
      observation-compressor.ts
      raw-output-store.ts
      signal-extractor.ts
      index.ts

  evidence/
    src/
      evidence-recorder.ts
      artifact-hasher.ts
      evidence-linker.ts
      index.ts

  replay/
    src/
      replay-builder.ts
      replay-step.ts
      index.ts

  report/
    src/
      markdown-report.ts
      report-template.ts
      report-data-loader.ts
      index.ts

  parsers/
    src/
      route-parser.ts
      sink-parser.ts
      http-response-parser.ts
      log-parser.ts
      index.ts
```

---

## 5. Typed Action Interface

Nếu Codex 1 đã tạo core types, import từ đó.

```ts
export type PenHubActionInput = {
  challengeId: string
  workspacePath: string
  branchId?: string
  hypothesisId?: string
  args: Record<string, unknown>
}

export type PenHubActionResult = {
  actionId: string
  status: "success" | "failed" | "blocked"
  summary: string
  facts: PenHubFact[]
  evidence: PenHubEvidence[]
  artifacts: string[]
  rawOutputPath?: string
  tokenHint?: {
    includeInContext: boolean
    compressedSummary: string
  }
}
```

Rule:

```text
- Action result phải ngắn.
- Raw output lưu artifact.
- compressedSummary là thứ được đưa vào context.
- evidence phải link branch/hypothesis nếu có.
```

---

## 6. Action Registry

API:

```ts
export interface ActionRegistry {
  register(action: PenHubAction): void
  get(actionName: string): PenHubAction | undefined
  list(): PenHubActionManifest[]
}

export type PenHubActionManifest = {
  name: string
  description: string
  riskLevel: "read-only" | "local-exec" | "network-local" | "manual"
  inputSchema: unknown
  outputSchema: unknown
}
```

Codex 2 không implement full exploit engine. Phase này tập trung local CTF/lab safe actions.

---

## 7. Actions phải implement

### 7.1. `inspect_tree`

Liệt kê structure challenge.

Input:

```json
{
  "maxDepth": 4,
  "ignore": ["node_modules", ".git", "dist", "build"]
}
```

Output facts:

```text
- Dockerfile exists
- package.json exists
- src/routes.ts exists
```

### 7.2. `summarize_files`

Tóm tắt file được chọn, không dump file dài.

Input:

```json
{
  "paths": ["src/server.ts", "src/routes.ts"],
  "maxLinesPerFile": 80
}
```

### 7.3. `extract_routes`

Tìm route từ source.

Output:

```json
{
  "routes": [
    {"method": "GET", "path": "/api/preview", "file": "src/routes.ts"}
  ]
}
```

### 7.4. `extract_inputs`

Tìm input sources:

```text
req.query
req.body
req.params
headers
cookies
uploaded files
environment variables
```

### 7.5. `extract_sinks`

Tìm dangerous/sensitive sinks:

```text
fetch/request
child_process
template render
SQL query
file read/write
deserialization
eval/new Function
URL parser
redirect
```

### 7.6. `run_local_app`

Chạy app local bằng Docker Compose hoặc script local được cấu hình.

Rules:

```text
- Chỉ chạy local workspace.
- Không target internet.
- Timeout bắt buộc.
- Lưu logs vào artifact.
```

### 7.7. `send_request`

HTTP client wrapper cho local target.

### 7.8. `compare_responses`

So sánh hai response để phát hiện diff/auth/state.

### 7.9. `inspect_logs`

Đọc logs local, nén signal.

### 7.10. `record_evidence`

Ghi evidence vào `.penhub/state/evidence.jsonl`.

### 7.11. `update_hypothesis`

Gọi Hypothesis Engine nếu có, hoặc ghi transition request.

### 7.12. `generate_report`

Gọi report generator.

---

## 8. Observation Compressor

Pipeline:

```text
raw output
→ store artifact
→ extract signals
→ classify facts/evidence/errors
→ compressed summary
→ action result
```

API:

```ts
export interface ObservationCompressor {
  compress(input: {
    actionName: string
    rawOutput: string
    maxSummaryChars?: number
    artifactPath?: string
  }): Promise<{
    summary: string
    signals: string[]
    errors: string[]
    includeInContext: boolean
  }>
}
```

Rules:

```text
- Nếu raw output > 4000 chars, không include raw vào context.
- Summary nên <= 1000 chars.
- Errors giữ stack trace dòng quan trọng.
- Evidence signal giữ URL/path/header/token/flag-like pattern nếu có.
```

---

## 9. Evidence Recorder

Evidence schema dùng type từ Codex 1 nếu có.

API:

```ts
export interface EvidenceRecorder {
  record(input: Omit<PenHubEvidence, "id" | "createdAt">): Promise<PenHubEvidence>
  hashArtifact(path: string): Promise<string>
}
```

Rules:

```text
- Evidence phải có summary.
- Nếu có artifact, phải hash artifact.
- Evidence phải support ít nhất fact/hypothesis/branch hoặc final flag.
```

---

## 10. Replay Builder

Replay step:

```ts
export type ReplayStep = {
  order: number
  description: string
  command?: string
  request?: {
    method: string
    url: string
    headers?: Record<string, string>
    body?: string
  }
  expectedSignal: string
}
```

Rules:

```text
- Replay chỉ cho local CTF/lab.
- Không tạo instruction đánh target ngoài scope.
- Có thể ghi docker compose/curl/npm commands nếu là local.
```

---

## 11. Report Generator

Report Markdown gồm:

```markdown
# PenHub CTF/Pentest Report

## Summary
## Challenge
## Final Result / Flag
## Attack Chain
## Evidence Table
## Replay Steps
## Failed Branches
## Token Usage
## Human Effort
## Appendix: Artifacts
```

Report đọc từ:

```text
.penhub/state/challenge.json
.penhub/state/facts.jsonl
.penhub/state/hypotheses.jsonl
.penhub/state/branches.jsonl
.penhub/state/evidence.jsonl
.penhub/state/token_usage.json
```

Không đọc từ chat transcript.

---

## 12. Tests bắt buộc

Tạo:

```text
tests/actions/action-registry.test.ts
tests/actions/extract-routes.test.ts
tests/actions/send-request.test.ts
tests/observation/observation-compressor.test.ts
tests/evidence/evidence-recorder.test.ts
tests/replay/replay-builder.test.ts
tests/report/markdown-report.test.ts
```

Test cases:

```text
1. action registry register/list/get works.
2. extract_routes finds sample Express routes.
3. observation compressor stores raw output and returns compact summary.
4. evidence recorder hashes artifact.
5. replay builder generates ordered steps.
6. report generator includes evidence and token stats.
```

---

## 13. Prompt cho Codex 2

```text
You are Codex 2 — Typed Actions, Evidence, Replay, and Report Lead for PenHub.

PenHub is an OpenCode fork that changes the agent operating loop for CTF/pentest solving. Your task is to implement the typed action runtime and evidence pipeline. Do not edit core runtime/state/context/attack-tree modules except importing their types.

Only edit:
- packages/actions/**
- packages/tools/**
- packages/observation/**
- packages/evidence/**
- packages/replay/**
- packages/report/**
- packages/parsers/**
- packages/types/actions/**
- related tests and fixtures

Build:
1. ActionRegistry and typed ActionRunner.
2. Typed actions:
   - inspect_tree
   - summarize_files
   - extract_routes
   - extract_inputs
   - extract_sinks
   - run_local_app
   - send_request
   - compare_responses
   - inspect_logs
   - record_evidence
   - update_hypothesis
   - generate_report
3. ObservationCompressor:
   - store raw output as artifact
   - extract signal
   - return compact summary
4. EvidenceRecorder:
   - append evidence to state
   - hash artifacts
   - link evidence to branch/hypothesis/fact
5. ReplayBuilder.
6. Markdown report generator.
7. Tests and small fixtures.

Rules:
- Never inject raw large output into model context.
- Do not access internet targets; actions are local CTF/lab oriented.
- Do not modify UI/benchmark/CI/core state modules.
- Do not modify package.json or lockfiles unless explicitly required.

Acceptance:
- make check passes.
- Action results are typed.
- Raw output compression works.
- Evidence JSONL can be written.
- Report markdown can be generated from fixture state.
```

---

## 14. PR checklist Codex 2

```text
[ ] Branch là codex/2-actions-evidence-report.
[ ] Chỉ sửa file trong ownership.
[ ] Không duplicate core types.
[ ] Không sửa package.json/lockfile/CI.
[ ] make check pass.
[ ] Tests actions/observation/evidence/replay/report pass.
[ ] Raw output fixtures nhỏ.
[ ] Report đọc state/evidence, không đọc chat transcript.
[ ] PR target là dev.
```

PR title:

```text
[Codex 2] feat(actions): add typed actions and evidence pipeline
```
