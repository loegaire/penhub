# PenHub — Codex 3 Plan: UI Differentiation, Benchmark Harness, GitHub Integration & Conflict Guard

> Vai trò: **UI + Benchmark + Integration Lead**  
> Branch chuẩn: `codex/3-ui-benchmark-integration`  
> Mục tiêu: tạo UI khác OpenCode, benchmark OpenCode vs PenHub, và đảm bảo 3 Codex push GitHub không xung đột.

---

## 1. Mục tiêu của Codex 3

Codex 3 gom 3 phần có liên quan chặt:

```text
1. PenHub UI / workspace experience
2. Benchmark harness so sánh OpenCode upstream vs PenHub
3. GitHub integration, CI, PR templates, conflict guard
```

Lý do gộp:

```text
- UI cần đọc state do Codex 1/2 tạo.
- Benchmark cần hiển thị metrics trong UI/report.
- CI cần chạy tests của cả core/action/UI/benchmark.
- Gộp vào một Codex giúp giảm conflict ở .github, Makefile, scripts, docs.
```

---

## 2. Git branch và worktree

Tạo workspace riêng:

```bash
git fetch origin
git worktree add ../penhub-worktrees/codex-3-ui-benchmark -b codex/3-ui-benchmark-integration origin/dev
cd ../penhub-worktrees/codex-3-ui-benchmark
```

Trước khi code:

```bash
git branch --show-current
git status --short
git fetch origin
git rebase origin/dev
```

Trước khi push:

```bash
git fetch origin
git rebase origin/dev
make check
git diff --check
git push -u origin codex/3-ui-benchmark-integration
```

Nếu đã push rồi và cần push sau rebase:

```bash
git push --force-with-lease origin codex/3-ui-benchmark-integration
```

---

## 3. Ownership: Codex 3 được sửa gì?

Codex 3 được sửa:

```text
apps/penhub-ui/**
apps/workspace-ui/**
packages/ui/**
packages/ui-state/**
packages/report-viewer/**
benchmarks/**
harness/**
scripts/**
docs/**
.github/**
tests/ui/**
tests/benchmark/**
tests/integration/**
fixtures/ui/**
fixtures/benchmarks/**
```

Codex 3 có thể sửa các file shared sau, nhưng phải cẩn thận và ghi rõ trong PR:

```text
Makefile
README.md
package.json
pnpm-lock.yaml
yarn.lock
package-lock.json
tsconfig.json
```

Codex 3 không được sửa implementation core/action nếu chưa có approval:

```text
packages/core/**
packages/state/**
packages/context/**
packages/hypotheses/**
packages/attack-tree/**
packages/actions/**
packages/evidence/**
packages/report/**
```

Nếu cần import types, dùng type từ Codex 1/2.

---

# Part A — PenHub UI

## 4. Mục tiêu UI

PenHub UI phải nhìn khác OpenCode.

OpenCode thường xoay quanh:

```text
chat
files
terminal
coding workflow
```

PenHub phải xoay quanh:

```text
challenge
attack graph
hypotheses
branches
evidence
token budget
failed paths
report
benchmark
```

UI phải chứng minh:

```text
PenHub không chỉ chat với model.
PenHub quản lý quá trình giải CTF/pentest như attack-state machine.
```

---

## 5. UI panels bắt buộc

### 5.1. Challenge Overview

Hiển thị:

```text
challenge name
challenge type
goal
workspace path
status
flag found / not found
report generated / not generated
```

### 5.2. Attack Graph / Branch Explorer

Hiển thị:

```text
active branches
confirmed branches
failed branches
stale branches
confidence
progress
token cost
evidence count
```

### 5.3. Hypothesis Panel

Hiển thị:

```text
open/testing/confirmed/failed hypotheses
required evidence
next test
confidence
linked branch
```

### 5.4. Evidence Timeline

Hiển thị:

```text
timestamp
evidence type
summary
supports branch/hypothesis
artifact path/hash
replay availability
```

### 5.5. Token Budget Panel

Hiển thị:

```text
total tokens
tokens by branch
tokens by action
compression ratio
stale branch waste
tokens to flag nếu benchmark có
```

### 5.6. Action Log

Hiển thị:

```text
action name
status
branch
hypothesis
summary
artifacts
duration
```

### 5.7. Failed Branches / Rabbit Holes

Hiển thị:

```text
branch goal
why failed
evidence against it
token cost wasted
revisit allowed?
```

### 5.8. Report Preview

Hiển thị Markdown report do Codex 2 sinh.

### 5.9. Benchmark Comparison Panel

Hiển thị:

```text
OpenCode baseline vs PenHub
solve_success
flag_found
time_to_flag
tokens_to_flag
tool_calls_count
repeated_actions_count
human_interventions_count
report_generated
```

---

## 6. UI structure

```text
apps/
  penhub-ui/
    src/
      app/
        page.tsx
        challenge/[id]/page.tsx
        benchmark/[id]/page.tsx
      components/
        layout/
          PenHubShell.tsx
          Sidebar.tsx
          TopBar.tsx
        panels/
          ChallengeOverview.tsx
          AttackGraphPanel.tsx
          BranchExplorer.tsx
          HypothesisPanel.tsx
          EvidenceTimeline.tsx
          TokenBudgetPanel.tsx
          ActionLogPanel.tsx
          FailedBranchesPanel.tsx
          ReportPreview.tsx
          BenchmarkComparisonPanel.tsx
        cards/
          BranchCard.tsx
          HypothesisCard.tsx
          EvidenceCard.tsx
        lib/
          loadWorkspaceState.ts
          loadBenchmarkResult.ts
          formatters.ts
          mockData.ts
```

Nếu repo dùng UI framework khác, giữ component boundaries tương tự.

---

## 7. UI fixtures

Tạo:

```text
fixtures/ui/workspace-state.sample.json
fixtures/ui/benchmark-comparison.sample.json
```

Workspace fixture phải có:

```text
1 challenge
5 facts
4 hypotheses: open/testing/confirmed/failed
4 branches: active/confirmed/failed/stale
6 evidence items
token usage by branch/action
1 report markdown sample
```

Benchmark fixture phải có:

```text
baseline result
PenHub result
deltas
conclusion marked as sample
```

Không ghi số benchmark thật nếu chưa đo. Dữ liệu fixture phải đánh dấu rõ:

```json
{
  "isSampleData": true
}
```

---

# Part B — Benchmark Harness

## 8. Benchmark mục tiêu

Benchmark phải so sánh:

```text
Model: GPT-5.5
Runner A: upstream OpenCode
Runner B: PenHub
Challenge: local CTF/lab same setup
Budget: same time/token limit
Human input: same initial instruction
```

Không claim kết quả nếu chưa đo.

---

## 9. Benchmark metrics

Schema:

```ts
export type BenchmarkRunResult = {
  runner: "opencode-baseline" | "penhub"
  caseId: string
  model: string
  startedAt: string
  finishedAt: string
  success: boolean
  flagFound: boolean
  flag?: string
  timeToFlagSeconds?: number
  totalTokens?: number
  toolCallsCount: number
  repeatedActionsCount: number
  failedBranchCount?: number
  humanInterventionsCount: number
  evidenceItemsCount?: number
  reportGenerated: boolean
  reportReplayabilityScore?: number
  notes?: string[]
}
```

Comparison:

```ts
export type BenchmarkComparison = {
  caseId: string
  model: string
  baseline: BenchmarkRunResult
  penhub: BenchmarkRunResult
  deltas: {
    tokens?: number
    timeSeconds?: number
    toolCalls?: number
    repeatedActions?: number
    humanInterventions?: number
  }
  conclusion: string
}
```

---

## 10. Benchmark structure

```text
benchmarks/
  cases/
    local-web-chain-001/
      README.md
      docker-compose.yml
      challenge/
      oracle.json
      expected_report_points.yaml

  runners/
    run_baseline_opencode.ts
    run_penhub.ts
    run_case.ts
    compare_runs.ts

  metrics/
    metrics-schema.ts
    token-counter.ts
    repeated-action-detector.ts
    report-score.ts

  reports/
    benchmark-report-template.md

harness/
  smoke/
    smoke-run.ts
  fixtures/
    baseline-result.sample.json
    penhub-result.sample.json
```

---

## 11. Benchmark report

Benchmark report Markdown:

```markdown
# PenHub Benchmark Report

## Setup
- model
- case
- budget
- runners

## Results
| Metric | OpenCode | PenHub | Delta |

## Evidence
- flag found?
- report generated?
- replay score?

## Notes
- no invented claims
- limitations
```

Rules:

```text
- Không bịa số liệu.
- Nếu chưa chạy thật, ghi "sample fixture".
- Nếu PenHub fail, report phải ghi fail.
```

---

# Part C — GitHub Integration & Conflict Guard

## 12. Makefile chuẩn

Codex 3 tạo hoặc chuẩn hóa:

```makefile
.PHONY: check test lint build benchmark-smoke format

check: lint test build

test:
	npm test

lint:
	npm run lint

build:
	npm run build

benchmark-smoke:
	npm run benchmark:smoke

format:
	npm run format
```

Nếu project không dùng npm, điều chỉnh theo package manager thực tế. Không tự đổi package manager.

---

## 13. GitHub Actions CI

Tạo:

```text
.github/workflows/ci.yml
```

Job tối thiểu:

```text
1. checkout
2. setup node/python nếu cần
3. install dependencies
4. lint
5. test
6. build
7. benchmark smoke
```

Không dùng secret trong smoke benchmark.

---

## 14. PR template

Tạo:

```text
.github/pull_request_template.md
```

Nội dung:

```markdown
## Summary
- ...

## Codex ownership
- [ ] Codex 1 Core
- [ ] Codex 2 Actions/Evidence/Report
- [ ] Codex 3 UI/Benchmark/Integration

## Files changed
- ...

## Validation
- [ ] make check
- [ ] make test
- [ ] make lint
- [ ] make build
- [ ] make benchmark-smoke, if relevant

## Shared files changed?
- [ ] No
- [ ] Yes, list:

## Risk
Low/Medium/High

## Screenshots / Benchmark output
If relevant.
```

---

## 15. CODEOWNERS

Tạo:

```text
.github/CODEOWNERS
```

Gợi ý:

```text
/packages/core/                 @codex-1-core
/packages/state/                @codex-1-core
/packages/context/              @codex-1-core
/packages/hypotheses/           @codex-1-core
/packages/attack-tree/          @codex-1-core
/packages/token-budget/         @codex-1-core

/packages/actions/              @codex-2-actions
/packages/observation/          @codex-2-actions
/packages/evidence/             @codex-2-actions
/packages/replay/               @codex-2-actions
/packages/report/               @codex-2-actions
/packages/parsers/              @codex-2-actions

/apps/penhub-ui/                @codex-3-integration
/benchmarks/                    @codex-3-integration
/harness/                       @codex-3-integration
/.github/                       @codex-3-integration
/docs/                          @codex-3-integration
```

Nếu repo không có GitHub users tương ứng, để comment hoặc docs thay vì enforced CODEOWNERS.

---

## 16. Conflict guard script

Tạo script:

```text
scripts/check-ownership.ts
```

Mục tiêu:

```text
- nhận CODEx_ID env: 1/2/3
- đọc git diff origin/dev...HEAD
- kiểm tra file changed có nằm ngoài ownership không
- nếu ngoài ownership, fail và in danh sách
```

Command:

```bash
CODEX_ID=1 npm run check:ownership
CODEX_ID=2 npm run check:ownership
CODEX_ID=3 npm run check:ownership
```

CI có thể không enforce CODEx_ID, nhưng local run phải có.

---

## 17. Git docs

Tạo docs:

```text
docs/git/3-codex-workflow.md
docs/git/conflict-runbook.md
docs/git/pr-checklist.md
```

Nội dung chính:

```text
- không push main/dev
- dùng worktree
- rebase origin/dev trước push
- force-with-lease chỉ trên branch cá nhân
- conflict shared file phải dừng
- không commit secrets/artifacts lớn
```

---

## 18. Prompt cho Codex 3

```text
You are Codex 3 — UI, Benchmark, and Integration Lead for PenHub.

PenHub is an OpenCode fork that changes the agent operating loop for CTF/pentest solving. Your task is to make PenHub visibly different from upstream OpenCode and ensure 3 Codex agents can push to GitHub safely.

Only edit:
- apps/penhub-ui/**
- apps/workspace-ui/**
- packages/ui/**
- packages/ui-state/**
- packages/report-viewer/**
- benchmarks/**
- harness/**
- scripts/**
- docs/**
- .github/**
- tests/ui/**
- tests/benchmark/**
- tests/integration/**
- fixtures/ui/**
- fixtures/benchmarks/**

Build UI:
1. PenHubShell.
2. ChallengeOverview.
3. AttackGraphPanel / BranchExplorer.
4. HypothesisPanel.
5. EvidenceTimeline.
6. TokenBudgetPanel.
7. ActionLogPanel.
8. FailedBranchesPanel.
9. ReportPreview.
10. BenchmarkComparisonPanel.

Build benchmark harness:
1. baseline OpenCode runner scaffold.
2. PenHub runner scaffold.
3. Metrics schema.
4. Comparison report generator.
5. Smoke benchmark using fixtures/local sample.

Build GitHub integration:
1. Makefile or update existing Makefile.
2. GitHub Actions CI.
3. PR template.
4. CODEOWNERS or ownership docs.
5. scripts/check-ownership.ts.
6. docs/git workflow and conflict runbook.

Rules:
- Do not edit core runtime or actions implementation.
- Do not invent benchmark results.
- Sample data must be marked isSampleData: true.
- If adding dependencies, document shared file changes.
- make check must pass.

Acceptance:
- UI renders from fixture workspace state.
- Benchmark comparison report can be generated from sample results.
- CI file exists.
- Ownership check script exists.
- Git docs exist.
- PR template exists.
```

---

## 19. PR checklist Codex 3

```text
[ ] Branch là codex/3-ui-benchmark-integration.
[ ] Không sửa core/actions implementation.
[ ] UI fixture có isSampleData nếu dùng số giả.
[ ] Benchmark không claim số chưa đo.
[ ] make check pass.
[ ] UI tests pass nếu có.
[ ] Benchmark smoke pass nếu có.
[ ] CI file hợp lệ.
[ ] PR target là dev.
```

PR title:

```text
[Codex 3] feat(workspace): add PenHub UI, benchmark harness, and GitHub guardrails
```

---

# Part D — Quy trình 3 Codex ghép code không conflict

## 20. Branch model

```text
main = stable
dev  = integration
codex/1-core-runtime
codex/2-actions-evidence-report
codex/3-ui-benchmark-integration
```

PR target luôn là:

```text
dev
```

Không PR trực tiếp vào `main`.

---

## 21. Merge order đề xuất

Thứ tự merge để ít conflict nhất:

```text
1. Codex 1 — core types + state contracts
2. Codex 2 — actions/evidence/report dùng type của Codex 1
3. Codex 3 — UI/benchmark/integration đọc state từ Codex 1/2
```

Nếu Codex 3 cần UI fixture trước khi Codex 1 merge, dùng fixture local nhưng sau đó phải align lại type.

---

## 22. Daily integration command

Mỗi Codex chạy:

```bash
git fetch origin
git rebase origin/dev
make check
```

Nếu conflict trong file ngoài ownership:

```text
Dừng.
Không tự resolve.
Tạo Conflict Report.
```

Conflict Report:

```markdown
## Conflict Report
Codex:
Branch:
Files:
Local change:
Incoming change:
Suggested resolution:
Risk:
```

---

## 23. Stop conditions

Codex phải dừng nếu:

```text
- đang ở branch main/dev và định commit
- cần sửa file ngoài ownership
- conflict trong package.json/lockfile/Makefile/schema/CI
- test fail ở module của Codex khác
- cần thêm dependency lớn
- benchmark metric thay đổi mạnh nhưng không có giải thích
- lỡ commit secret/token/log lớn
```

---

## 24. Final integration definition of done

Project đạt milestone nếu:

```text
[ ] Codex 1 merge: state/context/hypothesis/branch/token modules.
[ ] Codex 2 merge: typed actions/evidence/compression/report modules.
[ ] Codex 3 merge: UI/benchmark/CI/git guardrails.
[ ] make check pass trên dev.
[ ] benchmark smoke chạy được.
[ ] UI render từ fixture hoặc real state.
[ ] report markdown generate được.
[ ] không có conflict unresolved.
[ ] main chưa bị push trực tiếp.
```
