# PenHub — Codex 1 Plan: Core Runtime, Attack-State Memory, Context Builder & Planner

> Vai trò: **Core Runtime Lead**  
> Branch chuẩn: `codex/1-core-runtime`  
> Mục tiêu: thay đổi inner loop của OpenCode để PenHub vận hành như một CTF/pentest-native agent runtime.

---

## 1. Mục tiêu của Codex 1

Codex 1 xây phần lõi làm PenHub khác OpenCode upstream.

OpenCode upstream có xu hướng hoạt động như generic coding agent:

```text
User prompt
→ model đọc context
→ model gọi tool/bash/read/edit
→ tool output quay lại context
→ model tiếp tục
```

PenHub phải thêm một vòng lặp có trạng thái pentest:

```text
Challenge
→ Facts
→ Hypotheses
→ Attack branches
→ Evidence
→ Failed attempts
→ Token budget
→ Compact state card
→ Next best action
```

Codex 1 chịu trách nhiệm các module:

```text
1. PenHub mode scaffold
2. Attack-State Store
3. Context Builder v2
4. Hypothesis Engine
5. Evidence-Guided Attack Tree
6. Branch Scorer / Branch Pruner
7. Token Budget Manager
8. Core shared types
```

---

## 2. Git branch và worktree

Tạo workspace riêng cho Codex 1:

```bash
git fetch origin
git worktree add ../penhub-worktrees/codex-1-core -b codex/1-core-runtime origin/dev
cd ../penhub-worktrees/codex-1-core
```

Trước khi code:

```bash
git branch --show-current
git status --short
git fetch origin
git rebase origin/dev
```

Trước khi push:

```bash
git fetch origin
git rebase origin/dev
make check
git diff --check
git push -u origin codex/1-core-runtime
```

Nếu đã push rồi và cần push sau rebase:

```bash
git push --force-with-lease origin codex/1-core-runtime
```

Không bao giờ push vào:

```text
main
dev
codex/2-actions-evidence-report
codex/3-ui-benchmark-integration
```

---

## 3. Ownership: Codex 1 được sửa gì?

Codex 1 được sửa:

```text
packages/core/**
packages/types/core/**
packages/state/**
packages/context/**
packages/hypotheses/**
packages/attack-tree/**
packages/token-budget/**
tests/core/**
tests/state/**
tests/context/**
tests/hypotheses/**
tests/attack-tree/**
tests/token-budget/**
fixtures/state/**
```

Codex 1 không được sửa nếu chưa có approval:

```text
packages/actions/**
packages/evidence/**
packages/observation/**
packages/report/**
apps/penhub-ui/**
benchmarks/**
harness/**
.github/**
docs/git/**
package.json
pnpm-lock.yaml
yarn.lock
package-lock.json
Makefile
README.md
```

Nếu cần sửa shared files, Codex 1 phải ghi trong PR:

```markdown
## Shared File Change Request
File:
Reason:
Affected modules:
Required tests:
```

---

## 4. Repo structure Codex 1 cần tạo

```text
packages/
  types/
    core/
      src/
        challenge.ts
        fact.ts
        hypothesis.ts
        branch.ts
        evidence.ts
        token.ts
        workspace-state.ts
        index.ts

  core/
    src/
      penhub-mode.ts
      runtime-hooks.ts
      loop-controller.ts
      index.ts

  state/
    src/
      state-paths.ts
      state-init.ts
      jsonl-store.ts
      state-store.ts
      state-query.ts
      index.ts

  context/
    src/
      context-builder.ts
      state-card.ts
      state-compressor.ts
      context-budget.ts
      index.ts

  hypotheses/
    src/
      hypothesis-engine.ts
      hypothesis-transitions.ts
      index.ts

  attack-tree/
    src/
      attack-tree.ts
      branch-scorer.ts
      branch-pruner.ts
      next-action-selector.ts
      index.ts

  token-budget/
    src/
      token-usage-store.ts
      token-budget-manager.ts
      index.ts
```

---

## 5. State files của PenHub

Khi PenHub bắt đầu một challenge, phải tạo:

```text
.penhub/
  state/
    challenge.json
    facts.jsonl
    hypotheses.jsonl
    branches.jsonl
    evidence.jsonl
    failed_attempts.jsonl
    token_usage.json
    report.md
  artifacts/
  tmp/
```

Codex 1 tạo API quản lý state. Codex 2 sẽ ghi evidence/action result. Codex 3 sẽ đọc state để hiển thị UI và chạy benchmark.

---

## 6. Core types bắt buộc

### 6.1. Challenge

```ts
export type PenHubChallenge = {
  id: string
  name: string
  type: "web" | "crypto" | "pwn" | "rev" | "misc" | "cloud" | "unknown"
  goal: string
  workspacePath: string
  createdAt: string
}
```

### 6.2. Fact

```ts
export type PenHubFact = {
  id: string
  source: "source" | "runtime" | "tool" | "model" | "manual"
  claim: string
  confidence: number
  evidenceIds: string[]
  branchId?: string
  hypothesisId?: string
  createdAt: string
}
```

### 6.3. Hypothesis

```ts
export type PenHubHypothesis = {
  id: string
  claim: string
  status: "open" | "testing" | "confirmed" | "failed" | "stale"
  requiredEvidence: string[]
  nextTest?: string
  confidence: number
  branchId?: string
  createdAt: string
  updatedAt: string
}
```

### 6.4. Branch

```ts
export type PenHubBranch = {
  id: string
  goal: string
  status: "open" | "active" | "blocked" | "confirmed" | "failed" | "stale"
  confidence: number
  progress: number
  novelty: number
  tokenCost: number
  repetitionPenalty: number
  evidenceIds: string[]
  hypothesisIds: string[]
  createdAt: string
  updatedAt: string
}
```

### 6.5. Evidence placeholder type

Codex 1 định nghĩa type, Codex 2 implement recorder.

```ts
export type PenHubEvidence = {
  id: string
  type: "file" | "http" | "log" | "runtime" | "diff" | "flag" | "manual"
  summary: string
  artifactPath?: string
  hash?: string
  supports: string[]
  branchId?: string
  hypothesisId?: string
  createdAt: string
}
```

### 6.6. Workspace State

```ts
export type PenHubWorkspaceState = {
  challenge: PenHubChallenge
  facts: PenHubFact[]
  hypotheses: PenHubHypothesis[]
  branches: PenHubBranch[]
  evidence: PenHubEvidence[]
  tokenUsage: PenHubTokenUsage
}
```

---

## 7. AttackStateStore API

Implement:

```ts
export interface AttackStateStore {
  initChallenge(input: PenHubChallenge): Promise<void>
  readChallenge(): Promise<PenHubChallenge>

  appendFact(fact: PenHubFact): Promise<void>
  listFacts(filter?: StateFilter): Promise<PenHubFact[]>

  appendHypothesis(h: PenHubHypothesis): Promise<void>
  updateHypothesis(id: string, patch: Partial<PenHubHypothesis>): Promise<void>
  listHypotheses(filter?: StateFilter): Promise<PenHubHypothesis[]>

  appendBranch(branch: PenHubBranch): Promise<void>
  updateBranch(id: string, patch: Partial<PenHubBranch>): Promise<void>
  listBranches(filter?: StateFilter): Promise<PenHubBranch[]>

  appendEvidence(evidence: PenHubEvidence): Promise<void>
  listEvidence(filter?: StateFilter): Promise<PenHubEvidence[]>

  readWorkspaceState(): Promise<PenHubWorkspaceState>
}
```

Quy tắc:

```text
- JSONL cho facts/hypotheses/branches/evidence/failed attempts.
- Raw tool output không được lưu vào facts.
- Facts chỉ lưu claim ngắn + evidenceIds.
- State API phải deterministic và test được.
```

---

## 8. Context Builder v2

Codex 1 phải tạo context compact để giảm token.

Output dạng Markdown:

```markdown
# PenHub State Card

## Challenge
- Type:
- Goal:

## Verified Facts
1. ...

## Open Hypotheses
1. H1 — claim — confidence — next test

## Confirmed Primitives
1. ...

## Failed / Stale Branches
1. ...

## Evidence Summary
1. ...

## Token Budget
- total:
- active branch:

## Next Best Action Candidates
1. ...
```

API:

```ts
export interface PenHubContextBuilder {
  buildStateCard(input: {
    workspacePath: string
    maxFacts?: number
    maxHypotheses?: number
    maxBranches?: number
    tokenBudget?: number
  }): Promise<string>
}
```

Acceptance:

```text
- Không include raw logs dài.
- Không include full source file nếu không được action yêu cầu.
- State card phải ổn định khi input state không đổi.
- Có snapshot test.
```

---

## 9. Hypothesis Engine

Lifecycle:

```text
open → testing → confirmed
open → testing → failed
open → stale
```

API:

```ts
export interface HypothesisEngine {
  create(input: {
    claim: string
    requiredEvidence: string[]
    nextTest?: string
    confidence?: number
    branchId?: string
  }): Promise<PenHubHypothesis>

  markTesting(id: string): Promise<void>
  markConfirmed(id: string, evidenceIds: string[]): Promise<void>
  markFailed(id: string, reason: string): Promise<void>
  markStale(id: string, reason: string): Promise<void>
}
```

---

## 10. Branch Scorer / Pruner

Scoring ban đầu:

```ts
score = confidence * 0.35
      + progress * 0.30
      + novelty * 0.20
      - normalizedTokenCost * 0.10
      - repetitionPenalty * 0.05
```

Quy tắc:

```text
- Branch có evidence mới tăng priority.
- Branch lặp action nhiều giảm priority.
- Branch stale không được chọn làm next action.
- Branch token cost cao nhưng progress thấp bị giảm score.
```

API:

```ts
export function scoreBranch(branch: PenHubBranch): number
export function rankBranches(branches: PenHubBranch[]): PenHubBranch[]
export function pruneBranches(branches: PenHubBranch[]): PenHubBranch[]
```

---

## 11. Token Budget Manager

Track:

```text
tokens per branch
tokens per action
tokens per hypothesis
total tokens
compression ratio
```

API:

```ts
export interface TokenBudgetManager {
  recordUsage(input: {
    branchId?: string
    actionId?: string
    hypothesisId?: string
    inputTokens: number
    outputTokens: number
  }): Promise<void>

  summarize(): Promise<PenHubTokenUsage>
}
```

---

## 12. Tests bắt buộc

Tạo tests:

```text
tests/state/state-store.test.ts
tests/context/context-builder.test.ts
tests/hypotheses/hypothesis-engine.test.ts
tests/attack-tree/branch-scorer.test.ts
tests/token-budget/token-budget-manager.test.ts
```

Test cases:

```text
1. init challenge tạo .penhub/state đầy đủ.
2. append/read facts hoạt động.
3. hypothesis lifecycle đúng.
4. branch scorer rank đúng.
5. context builder không include raw long output.
6. token usage summary đúng.
7. readWorkspaceState trả đúng shape.
```

---

## 13. Prompt cho Codex 1

```text
You are Codex 1 — Core Runtime Lead for PenHub.

PenHub is an OpenCode fork that changes the agent operating loop for CTF/pentest solving. Your task is to implement the core state and planning runtime, not UI and not typed tools.

Only edit:
- packages/core/**
- packages/types/core/**
- packages/state/**
- packages/context/**
- packages/hypotheses/**
- packages/attack-tree/**
- packages/token-budget/**
- related tests and fixtures

Build:
1. Core PenHub types: Challenge, Fact, Hypothesis, Branch, Evidence, TokenUsage, WorkspaceState.
2. .penhub/state initialization.
3. JSONL-backed AttackStateStore.
4. Context Builder v2 producing compact PenHub State Card.
5. Hypothesis Engine with lifecycle open/testing/confirmed/failed/stale.
6. Evidence-Guided Attack Tree with branch scoring and pruning.
7. Token Budget Manager with usage tracking and summary.
8. Unit tests for all modules.

Rules:
- Do not inject raw long tool output into context.
- Do not edit actions/evidence/report/UI/benchmark modules.
- Do not modify package.json, lockfile, Makefile, or CI unless explicitly required.
- If you need a shared type change, document it in the PR.

Acceptance:
- make check passes.
- State initialization works.
- Context card is compact and deterministic.
- Hypothesis lifecycle is persisted.
- Branch scorer prioritizes evidence-backed, low-waste branches.
- Token usage can be summarized by branch/action/hypothesis.
```

---

## 14. PR checklist Codex 1

```text
[ ] Branch là codex/1-core-runtime.
[ ] Chỉ sửa file trong ownership.
[ ] Không sửa package.json/lockfile/CI.
[ ] make check pass.
[ ] Tests state/context/hypotheses/attack-tree/token-budget pass.
[ ] Không commit .penhub runtime artifacts ngoài fixtures.
[ ] PR target là dev.
```

PR title:

```text
[Codex 1] feat(core): add PenHub attack-state runtime
```
